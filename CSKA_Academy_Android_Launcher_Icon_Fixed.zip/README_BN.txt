CSKA Academy Android Project

এই ZIP-টি GitHub repository-র root হিসেবে আপলোড করার জন্য সাজানো source project; এটি APK নয়।

GitHub Actions workflow অবস্থান: .github/workflows/build-apk.yml
Build: Gradle 8.9, JDK 17, Android SDK Platform 35, Build Tools 35.0.0.

গুরুত্বপূর্ণ:
- Google Drive-এ ব্যাকআপ Save/Open picker দিয়ে ম্যানুয়ালি করা যায়; এটি automatic background sync নয়।
- পুরোনো অ্যাপের localStorage নতুন APK-তে নিজে থেকে স্থানান্তরিত হবে না। JSON backup নিয়ে নতুন অ্যাপে Restore করতে হবে।
- APK তৈরি হয়েছে বলে ধরে নেওয়া যাবে না; GitHub Actions সফলভাবে শেষ হলে Artifacts থেকে APK নিতে হবে।
